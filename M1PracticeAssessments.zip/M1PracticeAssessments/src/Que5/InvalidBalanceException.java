package Que5;

public class InvalidBalanceException extends Exception {
	public InvalidBalanceException(String s) {
		super(s);
	}
}

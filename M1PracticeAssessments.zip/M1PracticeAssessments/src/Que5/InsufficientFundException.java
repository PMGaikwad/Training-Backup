package Que5;

public class InsufficientFundException extends Exception {
	public InsufficientFundException(String s) {
		super(s);
	}

}

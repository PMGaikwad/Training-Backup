package Que5;

public class Customer {
	String userName;
	int balance;
	public Customer() {
		super();
	}
	
	public Customer(String userName, int balance) {
		super();
		this.userName = userName;
		this.balance = balance;
	}
	
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [userName=" + userName + ", balance=" + balance + "]";
	}
}

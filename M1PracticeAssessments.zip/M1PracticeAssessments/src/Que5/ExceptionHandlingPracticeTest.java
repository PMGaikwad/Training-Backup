package Que5;

import java.util.Scanner;

public class ExceptionHandlingPracticeTest{
	public static void main(String[] args)throws InvalidUserNameException,InvalidBalanceException, InsufficientFundException {
		Scanner sc=new Scanner(System.in);
		String userName=sc.next();
		int balance=sc.nextInt();
		
		if(userName.equals(null)) {
			throw new InvalidUserNameException("Username block is empty");
		}
		if(balance==0) {
			throw new InvalidBalanceException("Balance is not enough");
		}
		else {
			Customer c=new Customer(userName,balance);
			BillPaymentService b=new BillPaymentService();
			boolean status=b.payBill(c, balance);
			System.out.println(status);
		}
		
	}

}

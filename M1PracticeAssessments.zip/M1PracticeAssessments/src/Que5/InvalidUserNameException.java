package Que5;

public class InvalidUserNameException extends Exception {
	public InvalidUserNameException(String s) {
		super(s);
	}

}

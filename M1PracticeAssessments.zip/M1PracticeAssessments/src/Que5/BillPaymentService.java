package Que5;

import MakeMyHoliday.Hotels;

public class BillPaymentService {
	public boolean payBill(Customer customer,int amountToBePaid)throws InsufficientFundException {
		if(customer.balance<=500) {
			throw new InsufficientFundException("Can't execute this transaction due to Insufficient balance");
		}
		else {
			customer.balance=customer.balance-amountToBePaid;
			return true;
		}
	}

}

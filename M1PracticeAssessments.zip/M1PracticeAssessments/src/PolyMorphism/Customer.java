package PolyMorphism;

abstract public class Customer {
	public String username;
	public int billAmount;

	public abstract int payBill();
	

}

package PolyMorphism;

public class PolyMorphismDemo {
	public static void main(String[] args) {
		// call doUserThings methods
		PolyMorphismDemo p=new PolyMorphismDemo();
		Customer c=new OnlineCustomer();
		p.doUserThings(c);
	}
	public void doUserThings(Customer customer)
	{
		// call claim cash back method
		OnlineCustomer o=new OnlineCustomer();
		o.billAmount=1000;
		System.out.println(o.claimCashBack());
	}

}

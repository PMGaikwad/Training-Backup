package PolyMorphism;

public class OnlineCustomer extends Customer {

	public int payBill() {
		return 1000;
	}

	public float claimCashBack() {
		return super.billAmount * 0.05f;
	}

}

package CustomerRecords;

import java.util.Objects;

public class Customer {
	private String userName;
	private String emailId;
	private Address address;
	private int orderValue;
	private String paymentType;
	private String status;
	
	public Customer() {
		
	}


	public Customer(String userName, String emailId, Address address, int orderValue, String paymentType,
			String status) {
		super();
		this.userName = userName;
		this.emailId = emailId;
		this.address = address;
		this.orderValue = orderValue;
		this.paymentType = paymentType;
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(int orderValue) {
		this.orderValue = orderValue;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, emailId, orderValue, paymentType, status, userName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(address, other.address) && Objects.equals(emailId, other.emailId)
				&& orderValue == other.orderValue && Objects.equals(paymentType, other.paymentType)
				&& Objects.equals(status, other.status) && Objects.equals(userName, other.userName);
	}

	@Override
	public String toString() {
		return "Customer [userName=" + userName + ", emailId=" + emailId + ", address=" + address + ", orderValue="
				+ orderValue + ", paymentType=" + paymentType + ", status=" + status + "]";
	}
	
	

}

package PanCardVerification;

import java.util.Objects;

public class Documents {
	private String panNumber;
	private String passportNumber;
	
	public Documents() {
	}

	public Documents(String panNumber, String passportNumber) {
		this.panNumber = panNumber;
		this.passportNumber = passportNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	@Override
	public String toString() {
		return "Documents [panNumber=" + panNumber + ", passportNumber=" + passportNumber + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(panNumber, passportNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Documents other = (Documents) obj;
		return Objects.equals(panNumber, other.panNumber) && Objects.equals(passportNumber, other.passportNumber);
	}
	
	
	
	
	
	

}

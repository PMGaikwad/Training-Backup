package PanCardVerification;

import java.util.Scanner;
import java.util.regex.Pattern;

public class PanVerification {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		
		
		System.out.print("Enter the Pan Card Number: ");
		String panNumber=sc.next();
		System.out.print("Enter the PassPort Number: ");
		String passportNumber=sc.next();
		
		String panNumberPattern="[A-Z]{5}[0-9]{4}[A-Z]{1}";
		String passportNumberPattern="[ABCDK]{1}[0-9]{6}[A-Z]{1}";
		
		boolean b1=Pattern.matches(panNumberPattern, panNumber);
		boolean b2=Pattern.matches(passportNumberPattern, passportNumber);
		
		if(b1 && b2) {
			Documents document=new Documents(panNumber,passportNumber);
			System.out.println(document);
		}
		else {
			Documents d=new Documents(null,null);
			System.out.println("Not a Valid PanCard Number or Password");
		}
		
	}

}

package com.cg.firstapp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.firstapp.entity.Account;
import com.cg.firstapp.entity.Transaction;

public class MainApp {
	
	public static void main(String[] args) {
		
		ApplicationContext spring = new ClassPathXmlApplicationContext("abc.xml");
		
		Account a = spring.getBean("account",Account.class);
		System.out.println(a);
		
		System.out.println("Policy of A1 :- "+ a.getPolicy().getPolicyName());
	}
}

package ProductApp;

import java.time.LocalDate;  

import product.app.dao.DatabaseOperations;
import product.app.models.Certification;
import product.app.models.Product;
import product.app.models.Vendor;
import product.app.util.DateConverter;

public class MainApp {

	DatabaseOperations dbOps;

	public MainApp() {
		dbOps = new DatabaseOperations();
	}
	
	public static void main(String[] args) {
		MainApp app = new MainApp();
		//app.createProduct();
		app.getProduct();
		//Product p = new Product();
		//app.displayproduct(p);
	}
	
	public void getProduct() {
		int searchCode = 1;
		displayproduct(dbOps.getProductById(searchCode));
	}
	
	public void displayproduct(Product p) {
		System.out.println(p);
	}
	
	public void createProduct() {
		String strDom = "12-2-1989";
		String strDoe = "20-3-1989";
		
		LocalDate dom = DateConverter.getDateFromString(strDom);
		LocalDate doe = DateConverter.getDateFromString(strDoe);
		
		Product p1 = new Product("STS", 10000, dom, doe, "IT");
		Certification c1 = new Certification("Best It Product", 1000);
		p1.setCr(c1);
		Vendor v1 = new Vendor(1, "CG", "Banglore");
		p1.setVr(v1);
		
		Product p2 = new Product("Piston", 5000, dom, doe, "Mechanical");
		Certification c2 = new Certification("Best Mech Product", 1500);
		p2.setCr(c2);
		Vendor v2 = new Vendor(2,"Cooper","Satara");
		p2.setVr(v2);
		
		dbOps.savedProduct(p1);
		dbOps.savedProduct(p2);
	}
}

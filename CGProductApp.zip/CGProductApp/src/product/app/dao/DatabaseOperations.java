package product.app.dao;

import java.util.Set; 

import org.hibernate.Session; 
import org.hibernate.Transaction;

import product.app.models.Product;

public class DatabaseOperations {

	public static Session hibernateSession ;

	public DatabaseOperations() {
		hibernateSession = HibernateConfiguration.hibernateSession;
	}
	
	public Product getProductById(int productCode) {
		Product p = (Product)hibernateSession.get(Product.class, productCode);
		return p;
	}
	
	public void savedProduct(Product p) {
		if(p != null) {
			Transaction t = hibernateSession.beginTransaction();
			hibernateSession.save(p);
			t.commit();
		}
	}
	
}

package product.app.models;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.annotations.CollectionId;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
public class Vendor {
	
	@Column(nullable = false,unique = true)
	private int vendorId;
	@Column(unique = true)
	private String vendorName;
	private String vendorLocation;
	
	public Vendor() {
		super();
	}

	public Vendor(int vendorId, String vendorName, String vendorLocation) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.vendorLocation = vendorLocation;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorLocation() {
		return vendorLocation;
	}

	public void setVendorLocation(String vendorLocation) {
		this.vendorLocation = vendorLocation;
	}

	@Override
	public int hashCode() {
		return Objects.hash(vendorId, vendorLocation, vendorName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vendor other = (Vendor) obj;
		return vendorId == other.vendorId && Objects.equals(vendorLocation, other.vendorLocation)
				&& Objects.equals(vendorName, other.vendorName);
	}

	@Override
	public String toString() {
		return "Verification [vendorId=" + vendorId + ", vendorName=" + vendorName + ", vendorLocation="
				+ vendorLocation + "]";
	}
	
}

package product.app.models;

import java.time.LocalDate;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionId;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "CGProduct")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productCode;
	@Column(name = "ProductName", nullable = false)
	private String name;
	@Column(nullable = false)
	private int cost;
	private LocalDate dom;
	private LocalDate doe;
	private String category;
	
	@Embedded
	private Vendor vr;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cerificateId")
	private Certification cr;
	
	public Product() {
		super();
	}

	public Product(String name, int cost, LocalDate dom, LocalDate doe, String category) {
		super();
		this.name = name;
		this.cost = cost;
		this.dom = dom;
		this.doe = doe;
		this.category = category;
	}

	public int getProductCode() {
		return productCode;
	}

	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public LocalDate getDom() {
		return dom;
	}

	public void setDom(LocalDate dom) {
		this.dom = dom;
	}

	public LocalDate getDoe() {
		return doe;
	}

	public void setDoe(LocalDate doe) {
		this.doe = doe;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Vendor getVr() {
		return vr;
	}

	public void setVr(Vendor vr) {
		this.vr = vr;
	}

	public Certification getCr() {
		return cr;
	}

	public void setCr(Certification cr) {
		this.cr = cr;
	}

	@Override
	public int hashCode() {
		return Objects.hash(category, cost, doe, dom, name, productCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(category, other.category) && cost == other.cost && Objects.equals(doe, other.doe)
				&& Objects.equals(dom, other.dom) && Objects.equals(name, other.name)
				&& productCode == other.productCode;
	}

	@Override
	public String toString() {
		return "Product [productCode=" + productCode + ", name=" + name + ", cost=" + cost + ", dom=" + dom + ", doe="
				+ doe + ", category=" + category + "]";
	}
	
}

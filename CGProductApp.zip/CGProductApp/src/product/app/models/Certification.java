package product.app.models;

import java.util.Objects; 

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "CGCertification")
public class Certification {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long cerificateId;
	private String cName;
	private int cost;
	
	public Certification() {
		super();
	}
	
	public Certification(String cName, int cost) {
		super();
		this.cName = cName;
		this.cost = cost;
	}
	
	public long getCerificateId() {
		return cerificateId;
	}
	
	public void setCerificateId(long cerificateId) {
		this.cerificateId = cerificateId;
	}
	
	public String getcName() {
		return cName;
	}
	
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	public int getCost() {
		return cost;
	}
	
	public void setCost(int cost) {
		this.cost = cost;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cName, cerificateId, cost);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Certification other = (Certification) obj;
		return Objects.equals(cName, other.cName) && cerificateId == other.cerificateId && cost == other.cost;
	}

	@Override
	public String toString() {
		return "Certification [cerificateId=" + cerificateId + ", cName=" + cName + ", cost=" + cost + "]";
	}
	
}

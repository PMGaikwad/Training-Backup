package product.app.util;
import java.time.LocalDate;

import javax.persistence.criteria.CriteriaBuilder.In;


import product.app.models.Product;

public class Dump {
	public static void main(String[] args) {
		
		
		//System.out.println(d2);
	}
}




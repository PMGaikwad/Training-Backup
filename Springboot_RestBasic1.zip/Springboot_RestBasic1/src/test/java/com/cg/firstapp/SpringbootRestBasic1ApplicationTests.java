package com.cg.firstapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRestBasic1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.cg.firstapp.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.cg.firstapp.entity.Account;

@Component
public class AccountRepository {

	List<Account> allAcc = new ArrayList<>();

	public AccountRepository() {

		System.out.println("Inside Account Repository Constructor.");
		Account a1 = new Account(1,1234, "Pune", 10000, "Current");
		Account a2 = new Account(2,2345, "Satara", 5000, "Savings");
		Account a3 = new Account(3,3456, "Pune", 1000, "Salaried");
		
		allAcc.add(a3);
		allAcc.add(a2);
		allAcc.add(a1);
	}
	
	public Account getAccountByNum(int num) {
		return allAcc.stream().filter((a)->{
			if(a.getAccNum() == num) return true;
			else return false;
		}).findFirst().get();
	}
	
	public List<Account> getAllAccounts(){
		System.out.println("Inside getAccounts Repository."+allAcc.size());
		return allAcc;
	}
	
	public String saveAccount(Account a) {
		allAcc.add(a);
		return "Account Added "+ a.getAccNum();
	}
	
	public List<Account> getAllAccounts(String loc) {
		List<Account> locAcc = allAcc.stream().filter((a)->
			a.getLoc().equals(loc)).collect(Collectors.toList());
		return locAcc;
	}
	
	public Account updatePin(int num) {
		Account aa = allAcc.stream().filter((a)->{
			if(a.getAccNum() == num) {
				a.setPin(0000);
				return true;
			}else return false;
		}).findFirst().get();
		return aa;
	}
}

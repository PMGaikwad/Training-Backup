package com.cg.firstapp.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.firstapp.entity.Account;
import com.cg.firstapp.repository.AccountRepository;

@Service
public class AccountService implements IAccountService {
	
	@Autowired
	AccountRepository accRep;

	public AccountService() {
		System.out.println("Inside Account Service Constructor.");
	}

	@Override
	public String saveAccount(Account a) {
		if(a != null) {
			int id = new Random().nextInt(10000);
			a.setAccNum(id);
			return accRep.saveAccount(a);
		}
		return "Wrong Input Exception.";
	}

	@Override
	public Account getAccountByNum(int searchNum) {
		if(searchNum != 0) {
			Account a = accRep.getAccountByNum(searchNum);
			if (a != null) {
				return a;
			} else {
				return null;
			}
		}
		return null;
	}

	@Override
	public List<Account> getAllAccounts() {
		System.out.println("Inside Server getAllAccounts.");
		return accRep.getAllAccounts();
	}

	@Override
	public List<Account> getAllAccounts(String searchLoc) {
		return accRep.getAllAccounts(searchLoc);
	}

	@Override
	public Account updatePin(int searchNum) {
		if(searchNum != 0) {
			Account a = accRep.updatePin(searchNum);
			if (a != null) {
				return a;
			} else {
				return null;
			}
		}
		return null;
	}

	
}

package com.cg.firstapp.service;

import java.util.List; 

import com.cg.firstapp.entity.Account;

public interface IAccountService {
	
	public String saveAccount(Account a);
	public Account getAccountByNum(int searchNum);
	public List<Account> getAllAccounts();
	public List<Account> getAllAccounts(String searchLoc);
	public Account updatePin(int searchNum);
	
}

package com.cg.firstapp.entity;

import lombok.AllArgsConstructor; 
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Account {

	private int accNum;
	private int pin;
	private String loc;
	private int balance;
	private String accType;
	
	public Account(int pin, String loc, int balance, String accType) {
		super();
		this.pin = pin;
		this.loc = loc;
		this.balance = balance;
		this.accType = accType;
	}
	
}
